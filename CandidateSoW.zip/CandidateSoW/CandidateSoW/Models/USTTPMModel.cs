﻿namespace CandidateSoW.Models
{
    public class USTTPMModel
    {
        public int USTTPMId { get; set; }
        public string USTTPMName { get; set; } = "";

        public string Type { get; set; } = "";
    }
}
