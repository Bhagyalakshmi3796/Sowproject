import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DomainService } from '../services/domain.service';
import { ExcelService } from '../services/excel.service';
import { TechnologyService } from '../services/technology.service';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit {
  TechList:any=[];
  submitted:boolean=false;
  editmode:boolean=false;
  Id:any=null;
  DomainList:any=[];
  TechData:any=[];
  downloadObject:any;
  batchRecord:any=[];
  pageSizeSelected:number=10;
  currentPage:number=1;
  totalPages:number=0;

  constructor(private service:TechnologyService,private domainService:DomainService,private excelService:ExcelService) { }
  ngOnInit(): void {
    this.GetAllTechData();
  }

  techForm=new FormGroup({
    technologyName:new FormControl(),
    domainId: new FormControl()
  })

  GetAllTechData(){
    this.populateDropdowns();
    this.service.GetAllTechData().subscribe(data=>{
      this.TechList=data;
      this.totalPages=Math.ceil(this.TechList.length/this.pageSizeSelected)
      this.GetTechDetails();
      this.SetDefaultPagination();
    },err=>{
      console.log(err)
    })
  }
  
  populateDropdowns() {
    this.domainService.GetAllDomainData().subscribe(data=>{    
      this.DomainList=data; 
    },err => {
      console.log(err);
    })
  }

  onSubmit() {
    console.log(this.techForm.value);
    this.submitted = true;
    if (this.techForm.invalid) {
      return;
    }
    if (this.editmode) {
      this.onEdit();
    }
    else {
      this.onAdd();
    }
  }

  onEdit(){
    let formValue=this.techForm.value;
    let obj={
      technologyId:this.Id,
      technologyName:formValue.technologyName,
      domainId:formValue.domainId,
      type:'update'
    };
    this.service.UpdateTechData(this.Id,obj).subscribe(res=>{
      alert('Data updated successfully');
      this.techForm.reset();
      this.GetAllTechData();
      this.editmode=false;
      this.Id=null;
    },err=>{
      console.log(err);
      this.editmode=false;
      this.Id=null
    })
  }
  
  onAdd(){
    let formValue = this.techForm.value;
    let obj = {
      technologyName: formValue.technologyName,
      domainId:formValue.domainId,
      type: "post",
    };
    this.service.PostTechData(obj).subscribe(data => {
      console.log(data);
      alert("Technology Added Successfully");
      this.techForm.reset();
      this.GetAllTechData();
    })
  }

  editDetails(data:any){
    this.editmode=true;
    this.Id=data.technologyId;
    this.techForm.patchValue({
      technologyName: data.technologyName,
      domainId: data.domainId,
    })
  }

  getDomainName(id:any){
    var obj:any;
    this.DomainList.find((x:any)=>{
      if(x.domainId==id){
      obj=x;
    }
    })
    return obj.domainName;
  }
  // deleteDetails(tech:any){
  //   this.Id=tech.technologyId;
  //   var decision=confirm('Are you sure you want to delete?');
  //   if(decision){
  //     this.service.DeleteTechData(tech.technologyId).subscribe(res=>{
  //       alert('Technology with TechnologyId '+this.Id+ 'Deleted Successfully');
  //       this.GetAllTechData();
  //       this.Id=null;
  //     },err=>{
  //       alert(err);
  //     })
  //   }
  //  else{
  //   alert('Technology with TechnologyId ' +this.Id+ ' Not Deleted')
  //  }
  // }
  download(){
    this.downloadObject=this.createObject(this.TechData)
    console.log(this.TechData)
    let headers=[['Technology Id','Technology Name','Domain Name']]
    this.excelService.jsonExportAsExcel(this.downloadObject,"Technology Details",headers);
  }
  createObject(data){
    return {
      'Technology Data':data,
    }     
  }

  GetTechDetails(){
    this.TechList.forEach(element => {
      let obj={
        technologyId:element.technologyId,
        technologyName:element.technologyName,
        domainName:this.getDomainName(element.domainId)
      }
      this.TechData.push(obj);
    })
    console.log(this.TechData)
  }
  OnPreviousClicked() {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;

    this.currentPage -= 1;
    indexCounter = this.currentPage - 1;

    startIndex = indexCounter * Number(this.pageSizeSelected);
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.TechList.slice(startIndex, endIndex);
  }
  OnNextClicked() {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;

    this.currentPage += 1;
    indexCounter = this.currentPage - 1;

    startIndex = indexCounter * Number(this.pageSizeSelected);
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.TechList.slice(startIndex, endIndex);
  }

  OnPageNumberChanged(event: any) {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;
    let pageNumber = Math.floor(Number(event.target.value));

    if (pageNumber == 0 || pageNumber > this.totalPages) {
      this.currentPage = 1;
      event.target.value = this.currentPage;
      startIndex = 0;
    } else {
      indexCounter = pageNumber - 1;
      this.currentPage = pageNumber;
      event.target.value = pageNumber;
      startIndex = indexCounter * Number(this.pageSizeSelected);
    }
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.TechList.slice(startIndex, endIndex);
  }
  SetDefaultPagination() {
    let indexCounter: number = this.currentPage - 1;
    this.pageSizeSelected = 1;

    let startIndex: number = indexCounter * Number(this.pageSizeSelected);
    let endIndex: number = Number(this.pageSizeSelected) + startIndex;
    if (this.TechList) {
      this.batchRecord = this.TechList.slice(startIndex, endIndex);
    }
  }
}
