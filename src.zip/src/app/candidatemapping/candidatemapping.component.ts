import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { elementAt } from 'rxjs';
import { CandidateService } from '../services/candidate.service';
import { CandidatemappingService } from '../services/candidatemapping.service';
import { ExcelService } from '../services/excel.service';
import { SOWService } from '../services/sow.service';
import { StatusserviceService } from '../services/statusservice.service';

@Component({
  selector: 'app-candidatemapping',
  templateUrl: './candidatemapping.component.html',
  styleUrls: ['./candidatemapping.component.css']
})
export class CandidatemappingComponent implements OnInit {

  constructor(private service:CandidatemappingService,private candidateService:CandidateService,private sowService:SOWService,
    private statusService:StatusserviceService,private excelService:ExcelService) { }
  SowList:any=[];
  CandidateList:any=[];
  MappingsList:any=[];
  submitted:boolean=false;
  editmode:boolean=false;
  Id:any=null;
  statusList:any=[];
  MappingData:any=[];
  downloadObject:any;
  currentPage:number=1;
  totalPages:number=0;
  pageSizeSelected:number=10;
  batchRecord:any=[];

  ngOnInit(): void {  
    this.GetMappingsData();  
  }

  GetMappingsData(){
    this.populateDropdowns();
    this.service.GetAllCandidateMappingData().subscribe(res => {
      this.MappingsList = res;
      this.totalPages=Math.ceil(this.MappingsList.length/this.pageSizeSelected);
      this.GetSOCandidateDetails();
      this.SetDefaultPagination();
    }, err => {
      console.log(err);
    })
  }

  populateDropdowns(){
    this.sowService.GetAllSowData().subscribe(data=>{
      this.SowList=data;
    })
    this.candidateService.GetAllCandidatesData().subscribe(data=>{
      this.CandidateList=data;
    })
    this.statusService.GetAllStatusData().subscribe(data=>{
      this.statusList=data;
    })
  }
  
  mapppingForm = new FormGroup({
    candidateId: new FormControl(),
    sowId: new FormControl(),
    statusId: new FormControl()
  })

  onSubmit(){
    this.submitted=true;
    if(this.mapppingForm.invalid){
      return;
    }
    if(this.editmode){
      this.onEdit();
    }
    else{
      this.onAdd();
    }
  }

  onEdit(){
    let formValue=this.mapppingForm.value;
    let obj={
      soW_CandidateId:this.Id,
      sowId:formValue.sowId,
      candidateId:formValue.candidateId,
      statusId:formValue.statusId,
      type:'update'
    };
    this.service.UpdateCandidateMappingData(this.Id,obj).subscribe(res=>{
      alert('Data updated successfully');
      this.mapppingForm.reset();
      this.GetMappingsData();
      this.editmode=false;
      this.Id=null;
    },err=>{
      console.log(err);
      this.editmode=false;
      this.Id=null
    })
  }

  editDetails(data:any){
    debugger
    console.log(data)
    this.editmode=true;
    this.Id=data.soW_CandidateId;
    this.mapppingForm.patchValue({
      sowId:data.sowId,
      candidateId:data.candidateId,
      statusId:data.statusId,
    })
  }

  onAdd(){  
    let formValue = this.mapppingForm.value;
    console.log(formValue)
    let obj = {
      sowId: formValue.sowId,
      candidateId: formValue.candidateId,
      StatusId: formValue.statusId,
      type: "post",
    };
    this.service.PostCandidateMappingData(obj).subscribe(data => {
      console.log(data);
      alert("Candidate Added Successfully");
      this.mapppingForm.reset();
      this.GetMappingsData();
    })
  }

  deleteDetails(map:any){
    this.Id=map.soW_CandidateId;
    var decision=confirm('Are you sure you want to delete?');
    if(decision){
      this.service.DeleteCandidateMappingData(map.soW_CandidateId).subscribe(res=>{
        alert('Data Deleted Successfully');
        this.GetMappingsData();
        this.Id=null;
      })
    }
    else{
      alert('Data not Deleted');
    }
  }

  getSOName(id:any){
    var obj:any;
    this.SowList.find((x:any)=>{if(x.sowId==id){
      obj=x;
    }
    })
    return obj.soName;
  }
  
  getCandidateName(id:any){
    var obj:any;
    this.CandidateList.find((x:any)=>{if(x.candidateId==id){
      obj=x;
    }
    })
    return obj.candidateName;
  }

  getStatus(id:any){
    var obj:any;
    this.statusList.find((x:any)=>{if(x.statusId==id){
      obj=x;
    }
    })
    return obj.statusName;
  }
  download(){
    this.downloadObject=this.createObject(this.MappingData)
    console.log(this.MappingData)
    let headers=[['SO Candidate Id','SO Name','Candidate Name','Status']]
    this.excelService.jsonExportAsExcel(this.downloadObject,"SOCandidate Mapping",headers);
  }
  createObject(data){
    return {
      'SOCandidate Mapping Data':data,
    }     
  }

  GetSOCandidateDetails(){
    if(this.MappingsList!=undefined || this.MappingsList!=null){
      this.MappingsList.forEach(element => {
        let obj={
          soW_CandidateId:element.soW_CandidateId,
          sowName:this.getSOName(element.sowId),
          candidateName:this.getCandidateName(element.candidateId),
          status:this.getStatus(element.statusId)
        }
        this.MappingData.push(obj);
      })
      console.log(this.MappingData)
    }
    else{
      this.populateDropdowns();
      this.GetSOCandidateDetails();
    }
    
    }
    
    OnPreviousClicked() {
      let startIndex: number = 0;
      let endIndex: number = 0;
      let indexCounter: number = 0;
  
      this.currentPage -= 1;
      indexCounter = this.currentPage - 1;
  
      startIndex = indexCounter * Number(this.pageSizeSelected);
      endIndex = Number(this.pageSizeSelected) + startIndex;
  
      this.batchRecord = this.MappingsList.slice(startIndex, endIndex);
    }
    OnNextClicked() {
      let startIndex: number = 0;
      let endIndex: number = 0;
      let indexCounter: number = 0;
  
      this.currentPage += 1;
      indexCounter = this.currentPage - 1;
  
      startIndex = indexCounter * Number(this.pageSizeSelected);
      endIndex = Number(this.pageSizeSelected) + startIndex;
  
      this.batchRecord = this.MappingsList.slice(startIndex, endIndex);
    }
  
    OnPageNumberChanged(event: any) {
      let startIndex: number = 0;
      let endIndex: number = 0;
      let indexCounter: number = 0;
      let pageNumber = Math.floor(Number(event.target.value));
  
      if (pageNumber == 0 || pageNumber > this.totalPages) {
        this.currentPage = 1;
        event.target.value = this.currentPage;
        startIndex = 0;
      } else {
        indexCounter = pageNumber - 1;
        this.currentPage = pageNumber;
        event.target.value = pageNumber;
        startIndex = indexCounter * Number(this.pageSizeSelected);
      }
      endIndex = Number(this.pageSizeSelected) + startIndex;
  
      this.batchRecord = this.MappingsList.slice(startIndex, endIndex);
    }
    SetDefaultPagination() {
      let indexCounter: number = this.currentPage - 1;
      this.pageSizeSelected = 1;
  
      let startIndex: number = indexCounter * Number(this.pageSizeSelected);
      let endIndex: number = Number(this.pageSizeSelected) + startIndex;
      if (this.MappingsList) {
        this.batchRecord = this.MappingsList.slice(startIndex, endIndex);
      }
    }
}
