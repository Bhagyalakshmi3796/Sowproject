import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DomainService } from '../services/domain.service';
import { ExcelService } from '../services/excel.service';

@Component({
  selector: 'app-domain',
  templateUrl: './domain.component.html',
  styleUrls: ['./domain.component.css']
})
export class DomainComponent implements OnInit {
  DomainList:any=[];
  submitted:boolean=false;
  editmode:boolean=false;
  Id:any=null;
  downloadObject:any;
  DomainData:any=[];
  pageSizeSelected:number=10;
  currentPage:number=1;
  batchRecord:any=[];
  totalPages:number=0;

  constructor(private service:DomainService,private excelService:ExcelService) { }

  ngOnInit(): void {
    this.GetAllDomainData();
  }

  domainForm=new FormGroup({
    domainName:new FormControl()
  })

  GetAllDomainData(){
    this.service.GetAllDomainData().subscribe(data=>{
      this.DomainList=data;
      this.totalPages=Math.ceil(this.DomainList.length/this.pageSizeSelected);
      this.GetDomainDetails();
      this.SetDefaultPagination();
    },err=>{
      console.log(err)
    })
  }

  onSubmit() {
    console.log(this.domainForm.value);
    this.submitted = true;
    if (this.domainForm.invalid) {
      return;
    }
    if (this.editmode) {
      this.onEdit();
    }
    else {
      this.onAdd();
    }
  }

  onEdit(){
    let formValue=this.domainForm.value;
    let obj={
      domainId:this.Id,
      domainName:formValue.domainName,
      type:'update'
    };
    this.service.UpdateDomainData(this.Id,obj).subscribe(res=>{
      alert('Data updated successfully');
      this.domainForm.reset();
      this.GetAllDomainData();
      this.editmode=false;
      this.Id=null;
    },err=>{
      console.log(err);
      this.editmode=false;
      this.Id=null
    })
  }
  onAdd(){
    let formValue = this.domainForm.value;

    let obj = {
      domainName: formValue.domainName,
      type: "post",
    };
    this.service.PostDomainData(obj).subscribe(data => {
      console.log(data);
      alert("Domain Added Successfully");
      this.domainForm.reset();
      this.GetAllDomainData();
    })
  }
  editDetails(data:any){
    this.editmode=true;
    this.Id=data.domainId;
    this.domainForm.patchValue({
      domainName: data.domainName,
    })
  }

  download(){
    this.downloadObject=this.createObject(this.DomainData)
    console.log(this.DomainData)
    let headers=[['Domain Id','Domain Name']]
    this.excelService.jsonExportAsExcel(this.downloadObject,"Domain Details",headers);
  }
  createObject(data){
    return {
      'Domain Data':data,
    }     
  }

  GetDomainDetails(){
    this.DomainList.forEach(element => {
      let obj={
        domainId:element.domainId,
      domainName:element.domainName,
      }
      this.DomainData.push(obj);
    })
  }
  // deleteDetails(domain:any){
  //   this.Id=domain.domainId;
  //   var decision=confirm('Are you sure you want to delete?');
  //   if(decision){
  //     this.service.DeleteDomainData(domain.domainId).subscribe(res=>{
  //       alert('Domain with domainId '+this.Id+ 'Deleted Successfully');
  //       this.GetAllDomainData();
  //       this.Id=null;
  //     })
  //   }
  //  else{
  //   alert('Domain with domainId ' +this.Id+ ' Not Deleted')
  //  }
  //}

  OnPreviousClicked() {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;

    this.currentPage -= 1;
    indexCounter = this.currentPage - 1;

    startIndex = indexCounter * Number(this.pageSizeSelected);
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.DomainList.slice(startIndex, endIndex);
  }
  OnNextClicked() {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;

    this.currentPage += 1;
    indexCounter = this.currentPage - 1;

    startIndex = indexCounter * Number(this.pageSizeSelected);
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.DomainList.slice(startIndex, endIndex);
  }

  OnPageNumberChanged(event: any) {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;
    let pageNumber = Math.floor(Number(event.target.value));

    if (pageNumber == 0 || pageNumber > this.totalPages) {
      this.currentPage = 1;
      event.target.value = this.currentPage;
      startIndex = 0;
    } else {
      indexCounter = pageNumber - 1;
      this.currentPage = pageNumber;
      event.target.value = pageNumber;
      startIndex = indexCounter * Number(this.pageSizeSelected);
    }
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.DomainList.slice(startIndex, endIndex);
  }
  SetDefaultPagination() {
    let indexCounter: number = this.currentPage - 1;
    this.pageSizeSelected = 1;

    let startIndex: number = indexCounter * Number(this.pageSizeSelected);
    let endIndex: number = Number(this.pageSizeSelected) + startIndex;
    if (this.DomainList) {
      this.batchRecord = this.DomainList.slice(startIndex, endIndex);
    }
  }
}
