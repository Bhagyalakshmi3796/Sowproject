import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AccountserviceService } from '../services/accountservice.service';
import { CandidatemappingService } from '../services/candidatemapping.service';
import { DellmanagerserviceService } from '../services/dellmanagerservice.service';
import { ExcelService } from '../services/excel.service';
import { LocationserviceService } from '../services/locationservice.service';
import { RecruiterserviceService } from '../services/recruiterservice.service';
import { RegionserviceService } from '../services/regionservice.service';
import { SOWService } from '../services/sow.service';
import { StatusserviceService } from '../services/statusservice.service';
import { TechnologyService } from '../services/technology.service';
import { UstpocserviceService } from '../services/ustpocservice.service';
import { UsttpmserviceService } from '../services/usttpmservice.service';

@Component({
  selector: 'app-sow',
  templateUrl: './sow.component.html',
  styleUrls: ['./sow.component.css']
})
export class SOWComponent implements OnInit {
  SowList: any = []
  submitted: boolean = false;
  editmode: boolean = false;
  Id: any = null;
  regionList: any = [];
  accountList: any = [];
  technologyList: any = [];
  locationList: any = [];
  ustPocList: any = [];
  ustTpmList: any = [];
  recruiterList: any = [];
  dellManagerList: any = [];
  statusList: any = [];
  mappinglst:any=[];
  downloadObject:any;
  SOData:any=[];
  pageSizeSelected:number=10;
  batchRecord:any=[];
  currentPage:number=1;
  totalPages:number=0;

  constructor(private service: SOWService, private regionService: RegionserviceService, private locationService: LocationserviceService,
    private accountService: AccountserviceService, private tpmService: UsttpmserviceService, private pocService: UstpocserviceService, private recruiterService: RecruiterserviceService,
    private dellManagerService: DellmanagerserviceService, private statusService: StatusserviceService, private techService: TechnologyService, 
    private mappingService: CandidatemappingService,private excelService:ExcelService) { }

  ngOnInit(): void {
    this.GetSowData();
  }
  SowForm = new FormGroup({
    soName: new FormControl(),
    jrCode: new FormControl(),
    requestCreationDate: new FormControl(),
    accountId: new FormControl(),
    technologyId: new FormControl(),
    regionId: new FormControl(),
    role: new FormControl(),
    locationId: new FormControl(),
    targetOpenPositions: new FormControl(),
    positionsTobeClosed: new FormControl(),
    ustpocId: new FormControl(),
    recruiterId: new FormControl(),
    usttpmId: new FormControl(),
    dellManagerId: new FormControl(),
    statusId: new FormControl(),
    band: new FormControl(),
    projectId: new FormControl(),
    accountManager: new FormControl(),
    externalResource: new FormControl(),
    internalResource: new FormControl()
  })

  GetSowData() {
    this.populateDropdowns();
    this.service.GetAllSowData().subscribe(res => {
      console.log(res);
      this.SowList = res;
      this.totalPages=Math.ceil(this.SowList.length/this.pageSizeSelected);
      this.GetSODetails();
      this.SetDefaultPagination();
    }, err => {
      console.log(err);
    })
   
  }

  populateDropdowns() {
    this.techService.GetAllTechData().subscribe(res => {
      this.technologyList = res;
    }, err => {
      console.log(err);
    })
    this.accountService.GetAllAccountData().subscribe(res => {
      this.accountList = res;
    }, err => {
      console.log(err);
    })
    this.recruiterService.GetAllRecruiterData().subscribe(res => {
      this.recruiterList = res;
      console.log(this.recruiterList[0].recruiterName)
    }, err => {
      console.log(err);
    })
    this.pocService.GetAllUstPocData().subscribe(res => {
      this.ustPocList = res;
    }, err => {
      console.log(err);
    })
    this.dellManagerService.GetAllDellManagerData().subscribe(res => {
      this.dellManagerList = res;
    }, err => {
      console.log(err);
    })
    this.statusService.GetAllStatusData().subscribe(res => {
      this.statusList = res;
    }, err => {
      console.log(err);
    })
    this.regionService.GetAllRegionData().subscribe(res => {
      this.regionList = res;
    }, err => {
      console.log(err);
    })
    this.tpmService.GetAllUSTTPMData().subscribe(res => {
      this.ustTpmList = res;
    }, err => {
      console.log(err);
    })
    this.locationService.GetAllLocationData().subscribe(res => {
      this.locationList = res;
    }, err => {
      console.log(err);
    })
    this.mappingService.GetAllCandidateMappingData().subscribe((res) =>{
      this.mappinglst = res} ,
      err=>console.log(err))
  }

  
  onSubmit() {
    //debugger;
    console.log(this.SowForm.value);
    this.submitted = true;
    if (this.SowForm.invalid) {
      return;
    }
    if (this.editmode) {
      this.onEdit();
    }
    else {
      this.onAdd();
    }
  }
  onEdit() {
    let formValue = this.SowForm.value;

    let obj = {
      sowId: this.Id,
      soName: formValue.soName,
      jrCode: formValue.jrCode,
      requestCreationDate: formValue.requestCreationDate,
      accountId: formValue.accountId,
      technologyId: formValue.technologyId,
      role: formValue.role,
      regionId: formValue.regionId,
      locationId: formValue.locationId,
      targetOpenPositions: formValue.targetOpenPositions,
      positionsTobeClosed: formValue.positionsTobeClosed,
      ustpocId: formValue.ustpocId,
      recruiterId: formValue.recruiterId,
      usttpmId: formValue.usttpmId,
      dellManagerId: formValue.dellManagerId,
      statusId: formValue.statusId,
      band: formValue.band,
      projectId: formValue.projectId,
      accountManager: formValue.accountManager,
      internalResource: (formValue.internalResource == null) ? "" : formValue.internalResource,
      externalResource: (formValue.externalResource == null) ? "" : formValue.externalResource,
      type: "update",
    };
    this.service.UpdateSowData(this.Id, obj).subscribe(res => {
      alert('Data updated successfully');
      this.SowForm.reset();
      this.GetSowData();
      this.editmode = false;
      this.Id = null;
    }, err => {
      console.log(err);
      this.editmode = false;
      this.Id = null
    })
  }
  onAdd() {
    let formValue = this.SowForm.value;

    let obj = {
      soName: formValue.soName,
      jrCode: formValue.jrCode,
      requestCreationDate: formValue.requestCreationDate,
      accountId: formValue.accountId,
      technologyId: formValue.technologyId,
      role: formValue.role,
      regionId: formValue.regionId,
      locationId: formValue.locationId,
      targetOpenPositions: formValue.targetOpenPositions,
      positionsTobeClosed: formValue.positionsTobeClosed,
      ustpocId: formValue.ustpocId,
      recruiterId: formValue.recruiterId,
      usttpmId: formValue.usttpmId,
      dellManagerId: formValue.dellManagerId,
      statusId: formValue.statusId,
      band: formValue.band,
      projectId: formValue.projectId,
      accountManager: formValue.accountManager,
      internalResource: (formValue.internalResource == null) ? "" : formValue.internalResource,
      externalResource: (formValue.externalResource == null) ? "" : formValue.externalResource,
      type: "insert",
    };

    this.service.PostSowData(obj).subscribe(data => {
      console.log(data);
      alert("Candidate Added Successfully");
      this.SowForm.reset();
      this.GetSowData();
    })
  }

  editDetails(data: any) {
    this.editmode = true;
    this.Id = data.sowId;
    data.requestCreationDate = this.dateTrim(data.requestCreationDate)
    console.log(data.requestCreationDate)
    this.SowForm.patchValue({
      soName: data.soName,
      jrCode: data.jrCode,
      requestCreationDate: data.requestCreationDate,
      accountId: data.accountId,
      technologyId: data.technologyId,
      role: data.role,
      regionId: data.regionId,
      locationId: data.locationId,
      targetOpenPositions: data.targetOpenPositions,
      positionsTobeClosed: data.positionsTobeClosed,
      ustpocId: data.ustpocId,
      recruiterId: data.recruiterId,
      usttpmId: data.usttpmId,
      dellManagerId: data.dellManagerId,
      statusId: data.statusId,
      band: data.band,
      projectId: data.projectId,
      accountManager: data.accountManager,
      internalResource: data.internalResource,
      externalResource: data.externalResource
    })
  }

  deleteDetails(data: any) {
    this.Id = data.sowId;
    var obj: any = null;
    var decision = confirm('Are you sure you want to delete?');
    if (decision) {     
      this.mappinglst.find((x: any) => {
        if (x.sowId == this.Id) {
          obj = x;
        }
      })
      console.log(obj)
      if(obj==null){
        this.service.DeleteSowData(data.sowId).subscribe(res => {
          alert('Data Deleted Successfully');
          this.GetSowData();
          this.Id = null;
        })
      }
      else{
        alert('Mapping Exists for this SO with candidate.'+'\n'+'Please unmap and then delete');
      }
    }
    else {
      alert('Data not deleted');
    }
  }

  dateTrim(data: any) {
    let datearr = data.split("T")
    return datearr[0];
  }
  getAccount(id: any) {
    var obj: any;
    this.accountList.find((x: any) => {
      if (x.accountId == id) {
        obj = x;
      }
    })
    return obj.accountName;
  }
  getTechnology(id: any) {
    var obj: any;
    this.technologyList.find((x: any) => {
      if (x.technologyId == id) {
        obj = x;
      }
    })
    return obj.technologyName;
  }
  getLocation(id: any) {
    var obj: any;
    this.locationList.find((x: any) => {
      if (x.locationId == id) {
        obj = x;
      }
    })
    return obj.location;
  }
  getRegion(id: any) {
    var obj: any;
    this.regionList.find((x: any) => {
      if (x.regionId == id) {
        obj = x;
      }
    })
    return obj.region;
  }
  getUSTPOC(id: any) {
    var obj: any;
    this.ustPocList.find((x: any) => {
      if (x.ustpocId == id) {
        obj = x;
      }
    })
    return obj.ustpocName;
  }
  getUSTTPM(id: any) {
    var obj: any;
    this.ustTpmList.find((x: any) => {
      if (x.usttpmId == id) {
        obj = x;
      }
    })
    return obj.usttpmName;
  }
  getDellManager(id: any) {
    var obj: any;
    this.dellManagerList.find((x: any) => {
      if (x.dellManagerId == id) {
        obj = x;
      }
    })
    return obj.dellManagerName;
  }
  getStatus(id: any) {
    var obj: any;
    this.statusList.find((x: any) => {
      if (x.statusId == id) {
        obj = x;
      }
    })
    return obj.statusName;
  }
  getRecruiter(id: any) {
    var obj: any;
    this.recruiterList.find((x: any) => {
      if (x.recruiterId == id) {
        obj = x;
      }
    })
    return obj.recruiterName;
  }

  download(){
    this.downloadObject=this.createObject(this.SOData)
    console.log(this.SOData)
    let headers=[['SO Id','SO Name','JR Code','Request Creation Date','Account','Technology','Role','Region','Location','Target Open Positions',
    'Positions Tobe Closed','Ust POC','Recruiter','Ust TPM','Dell Manager','Status','Band','Project Id','Account Manager','External Resource',
    'Internal Resource']]
    this.excelService.jsonExportAsExcel(this.downloadObject,"SO Details",headers);
  }
  createObject(data){
    return {
      'SO Data':data,
    }     
  }

  GetSODetails(){
    this.SowList.forEach(element => {
      let obj={
        sowId:element.sowId,
        soName:element.soName,
        jrCode:element.jrCode,
        requestCreationDate:element.requestCreationDate,
        accountName:this.getAccount(element.accountId),
        technologyName:this.getTechnology(element.technologyId),
        role:element.role,
        region:this.getRegion(element.regionId),
        location:this.getLocation(element.locationId),
        targetOpenPositions:element.targetOpenPositions,
        positionsTobeClosed:element.positionsTobeClosed,
        ustpocName:this.getUSTPOC(element.ustpocId),
        recruiterName:this.getRecruiter(element.recruiterId),
        usttpmName:this.getUSTTPM(element.usttpmId),
        dellManagerName:this.getDellManager(element.dellManagerId),
        statusName:this.getStatus(element.statusId),
        band:element.band,
        projectId:element.projectId,
        accountManager:element.accountManager,
        externalResource:element.externalResource,
        internalResource:element.internalResource,
      }
      this.SOData.push(obj);
    })
    console.log(this.SOData)
  }
  OnPreviousClicked() {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;

    this.currentPage -= 1;
    indexCounter = this.currentPage - 1;

    startIndex = indexCounter * Number(this.pageSizeSelected);
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.SowList.slice(startIndex, endIndex);
  }
  OnNextClicked() {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;

    this.currentPage += 1;
    indexCounter = this.currentPage - 1;

    startIndex = indexCounter * Number(this.pageSizeSelected);
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.SowList.slice(startIndex, endIndex);
  }

  OnPageNumberChanged(event: any) {
    let startIndex: number = 0;
    let endIndex: number = 0;
    let indexCounter: number = 0;
    let pageNumber = Math.floor(Number(event.target.value));

    if (pageNumber == 0 || pageNumber > this.totalPages) {
      this.currentPage = 1;
      event.target.value = this.currentPage;
      startIndex = 0;
    } else {
      indexCounter = pageNumber - 1;
      this.currentPage = pageNumber;
      event.target.value = pageNumber;
      startIndex = indexCounter * Number(this.pageSizeSelected);
    }
    endIndex = Number(this.pageSizeSelected) + startIndex;

    this.batchRecord = this.SowList.slice(startIndex, endIndex);
  }
  SetDefaultPagination() {
    let indexCounter: number = this.currentPage - 1;
    this.pageSizeSelected = 1;

    let startIndex: number = indexCounter * Number(this.pageSizeSelected);
    let endIndex: number = Number(this.pageSizeSelected) + startIndex;
    if (this.SowList) {
      this.batchRecord = this.SowList.slice(startIndex, endIndex);
    }
  }
}    
